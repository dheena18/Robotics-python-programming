def read_world_data(filename):
    # Reads the world definition and returns a list of landmarks, our "map".
    # 
    # The returned dict contains a list of landmarks with the
    # following information: {id, [x, y]}

    #Create dictionary of landmark positions
    landmarks = dict()

    #Create file handle to access landmarks file
    f = open(filename)

    #Loop over all landmarks
    for line in f:
        #Remove the new line character
        line_s  = line.split('\n')
        #Split the line into individual pieces of information on a landmark
        line_spl  = line_s[0].split(' ')
        #Insert landmark information into dictionary
        landmarks[int(line_spl[0])] = [float(line_spl[1]),float(line_spl[2])]

    #Return completed landmark dictionary
    return landmarks

def read_sensor_data(filename):
    # Reads the odometry readings and sensor measurements from a file.
    #
    # The data is returned in a dict where the u_t and z_t are stored
    # together as follows:
    # 
    # {odometry,sensor}
    #
    # where "odometry" contains the fields r1, r2, t which contain the values of
    # the motion model variables of the same name, and sensor is a list of
    # sensor readings with id, range, bearing as values.
    #
    # The odometry and sensor values are accessed as follows:
    # odometry_data = sensor_readings[timestep, 'odometry']
    # sensor_data = sensor_readings[timestep, 'sensor']

    #Create dictionary of odometry and sensor data
    sensor_readings = dict()

    #Create lists with information on all sensor readings in one time step
    lm_ids =[]
    ranges=[]
    bearings=[]

    #Catch that it cannot be guaranteed that there are sensor readings in the file before odometry
    first_time = True
    #Number of time steps (odometry and sensor readings) + 1 recorded
    timestamp = 0
    #Create file handle to access sensor data file
    f = open(filename)

    #Loop over all odometry or sensor readings
    for line in f:
        # Remove the new line character
        line_s = line.split('\n')
        #Split the line into individual pieces of information of odometry / sensor readings
        line_spl = line_s[0].split(' ') 

        #The current line is an odometry reading
        if (line_spl[0]=='ODOMETRY'):

            #Insert odometry information into dictionary
            sensor_readings[timestamp,'odometry'] = {'r1':float(line_spl[1]),'t':float(line_spl[2]),'r2':float(line_spl[3])}

            #Deactivate first_time flag
            if first_time: 
                first_time = False
                
            else: 
                #Transfer old sensor readings to new time step so that a correction step can also be performed for each prediction step
                sensor_readings[timestamp,'sensor'] = {'id':lm_ids,'range':ranges,'bearing':bearings}
                #Empty lists with information on all sensor readings in one time step for the next
                lm_ids=[]
                ranges = []
                bearings = []

            #Ensure next incoming odometry reading is assigned to the next time step
            timestamp = timestamp+1
           
        #The current line is sensor reading
        if(line_spl[0]=='SENSOR'):

            #Add current sensor reading information to list for the time step of the last received odometry reading
            lm_ids.append(int(line_spl[1]))    
            ranges.append(float(line_spl[2]))
            bearings.append(float(line_spl[3]))
                              
        #Insert all sensor reading information for the time step of the last received odometry reading into the dictionary
        sensor_readings[timestamp-1,'sensor'] = {'id':lm_ids,'range':ranges,'bearing':bearings}            
    
    #Return completed sensor reading dictionary
    return sensor_readings
