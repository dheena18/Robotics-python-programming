#!/usr/bin/env python

from read_files import read_world_data, read_sensor_data
import numpy as np
import scipy.stats
import matplotlib.pyplot as plt

""" T 1 -- Particle Filter
"""

#DO NOT DELETE THIS LINE
np.random.seed(123)

#plot settings, interactive plotting mode
plt.axis([-1, 12, 0, 10])
plt.ion()
plt.show()

#global variable timestamp
timestamp = 0

def plot_filter_state(particles, landmarks, map_limits):
    # Visualizes the particle filter state.
    #
    # Displays the particle cloud, the mean position and the landmarks.
    
    xs = []
    ys = []

    for particle in particles:
        xs.append(particle['x'])
        ys.append(particle['y'])

    # landmark positions
    lx=[]
    ly=[]

    for i in range (len(landmarks)):
        #landmark indices start at one
        lx.append(landmarks[i+1][0])
        ly.append(landmarks[i+1][1])

    # mean pose as current estimate
    estimated_pose = mean_pose(particles)

    # plot filter state
    plt.clf()
    plt.plot(xs, ys, 'r.')
    plt.plot(lx, ly, 'bo',markersize=10)
    plt.quiver(estimated_pose[0], estimated_pose[1], np.cos(estimated_pose[2]), np.sin(estimated_pose[2]), angles='xy',scale_units='xy')
    plt.axis(map_limits)

    #for the first fifteen estimates
    if timestamp < 15:
        #output each on the console
        print("The robot pose estimate for time stamp ", timestamp, " is [x, y, theta] = [", "{:.3f}".format(estimated_pose[0]), "{:.3f}".format(estimated_pose[1]), "{:.3f}".format(estimated_pose[2]), "]")
        #save state of the particle filter
        plt.savefig("particle_filter_state_for_time_stamp_" + str(timestamp) + ".pdf")

    plt.pause(0.01)

def initialize_particles(num_particles, map_limits):
    # randomly initialize the particles inside the map limits

    particles = []

    for i in range(num_particles):
        particle = dict()

        # draw x,y and theta coordinate from uniform distribution
        # inside map limits
        particle['x'] = np.random.uniform(map_limits[0], map_limits[1])
        particle['y'] = np.random.uniform(map_limits[2], map_limits[3])
        particle['theta'] = np.random.uniform(-np.pi, np.pi)

        particles.append(particle)

    return particles

def mean_pose(particles):
    # calculate the average pose of a particle set.
    #
    # for x and y, the average position is the mean of the particle coordinates
    #
    # for theta, we cannot simply average the angles because of the wraparound 
    # (jump from -pi to pi). Therefore, we generate unit vectors from the 
    # angles and calculate the angle of their mean 

    # save x and y particle coordinates
    xs = []
    ys = []

    # save unit vectors corresponding to orientations of particles
    vxs_theta = []
    vys_theta = []

    for particle in particles:
        xs.append(particle['x'])
        ys.append(particle['y'])

        #create unit vector from particle orientation
        vxs_theta.append(np.cos(particle['theta']))
        vys_theta.append(np.sin(particle['theta']))

    #compute average coordinates
    mean_x = np.mean(xs)
    mean_y = np.mean(ys)
    mean_theta = np.arctan2(np.mean(vys_theta), np.mean(vxs_theta))

    return [mean_x, mean_y, mean_theta]

def sample_odometry_motion_model(odometry, particles):
    # Samples new particle poses, based on old poses, odometry
    # measurements and motion noise 
 
    delta_rot1 = odometry['r1']
    delta_trans = odometry['t']
    delta_rot2 = odometry['r2']

    # motion noise parameters: [alpha1, alpha2, alpha3, alpha4]
    noise = [0.1, 0.1, 0.05, 0.05]

    # generate new particle set after motion update
    new_particles = []
    
    '''Please insert your code here.'''
    '''***              ***'''


    

    
    #output the pose of the first particle drawn from the motion model
    if timestamp == 1:
        print("First particle drawn from the motion model has the pose [x, y, theta] = [", "{:.3f}".format(new_particles[0]['x']), "{:.3f}".format(new_particles[0]['y']), "{:.3f}".format(new_particles[0]['theta']),"]")

    return new_particles

def compute_importance_weights(sensor_data, particles, landmarks):
    # Calculates the observation likelihood of all particles, given the
    # particle and landmark positions and sensor readings
    #
    # The sensor model used is range only.

    sigma_r = 0.2

    #measured landmark ids and ranges
    ids = sensor_data['id']
    ranges = sensor_data['range']

    weights = []
    
    '''Please insert your code here.'''
    '''***              ***'''





    #normalize weights
    normalizer = sum(weights)
    weights = weights / normalizer

    #output the weight of the first particle drawn from the motion model
    if timestamp == 1:
        print("First particle drawn from the motion model has the weight w_1 = ", "{:.7f}".format(weights[0]))

    return weights

def resampling(particles, weights):
    # Returns a new set of particles obtained by stochastic
    # universal sampling according to particle weights.

    new_particles = []

    '''Please insert your code here.'''
    '''***              ***'''




    
    #output the pose of the first resampled particle
    if timestamp == 1:
        print("First resampled particle has the pose [x, y, theta] = [", "{:.3f}".format(new_particles[0]['x']), "{:.3f}".format(new_particles[1]['y']), "{:.3f}".format(new_particles[2]['theta']),"]")

    return new_particles

def main():
    # implementation of a particle filter for monte carlo localization

    global timestamp

    print("Reading landmark positions")
    landmarks = read_world_data("../data/world_data.dat")

    print("Reading sensor data")
    sensor_readings = read_sensor_data("../data/sensor_data.dat")

    #initialize the particles
    map_limits = [-1, 12, 0, 10]
    particles = initialize_particles(1000, map_limits)

    #run particle filter for all timestamps
    for timestamp in range(len(sensor_readings)//2):

        #plot the current state
        plot_filter_state(particles, landmarks, map_limits)

        #predict particles by sampling from motion model with odometry measurements
        new_particles = sample_odometry_motion_model(sensor_readings[timestamp,'odometry'], particles)

        #compute importance weights according to sensor model
        weights = compute_importance_weights(sensor_readings[timestamp, 'sensor'], new_particles, landmarks)

        #resample new particle set according to importance weights
        particles = resampling(new_particles, weights)

    plt.ioff()
    plt.show()

if __name__ == "__main__":
    main()
